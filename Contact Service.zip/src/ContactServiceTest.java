import java.util.Map;
import org.junit.jupiter.api.AfterEach;
import org.junit.jupiter.api.AfterAll;
import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.BeforeAll;
import org.junit.jupiter.api.Test;
import static org.junit.jupiter.api.Assertions.*;

/**
 *
*/
public class ContactServiceTest {
    
    public ContactServiceTest() {
    }
    
    @BeforeAll
    public static void setUpClass() {
    	
    }
    
    @AfterAll
    public static void tearDownClass() {
    }
    
    @BeforeEach
    public void setUp() {
    }
    
    @AfterEach
    public void tearDown() {
    }

    
    @Test
    public void testAddContact() {
        System.out.println("addContact");
        Contact contact = new Contact("2342","efg","erre","frec","wert");
        ContactService instance = new ContactService();
        Map<Integer, Contact> result = instance.addContact(contact) ;
        assertEquals(true, result.containsValue(contact));
        // TODO review the generated test code and remove the default call to fail.
        
    }

    
    @Test
    public void testDeleteContact() {
        System.out.println("deleteContact");
        Contact contact = new Contact("2342","efg","erre","frec","wert");
        ContactService instance = new ContactService();
        Map<Integer, Contact> result = instance.addContact(contact);
        boolean before = (result.containsValue(contact));
        instance.deleteContact("2342");
        boolean after = (result.containsValue(contact));
        assertEquals(false, before && after);
        // TODO review the generated test code and remove the default call to fail.
        
    }

    
    @Test
    public void testUpdateContact() {
        System.out.println("updateContact");
        String contactID = "2001";
        String firstName = "abc";
        String lastName = "defg";
        String Number = "hijk";
        String Address = "lmnop";
        Contact contact = null;
        Contact contactTest = new Contact("2001","aaa","bbb","ccc","ddd");
        ContactService instance = new ContactService();
        instance.addContact(contactTest);
        Map<Integer, Contact> result = instance.updateContact(contactID, firstName, lastName, Number, Address);
        assertEquals(true, result.get(2002).getContactID().equals("2001") && result.get(2002).getFirstName().equals("abc") && result.get(2002).getLastName().equals("defg") && result.get(2002).getNumber().equals("hijk") && result.get(2002).getAddress().equals("lmnop"));
        // TODO review the generated test code and remove the default call to fail.
        
    }
    
   
    
}

